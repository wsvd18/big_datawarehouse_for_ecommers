#!/bin/bash
APP=dwd
APP2=tempo2

if [ -n "$2" ];then
  do_date=$2
else
  do_date=`date -d "-1 day" +%F`
fi

sql1="
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nostrict;
set hive.exec.max.dynamic.partitions.pernode=1000;

insert overwrite table ${APP}.dwd_fac_order_detailinfo_di
select
    t1.id,
    t1.original_total_amount AS order_amount,
    t2.sku_num,
    substr(t1.create_time, 1, 10) AS ds,
    t1.order_status,
    substr(t1.create_time, 1, 10) AS create_time,
    t1.user_id,
    t2.sku_id,
    t1.province_id
from ${APP2}.ods_order_info t1
join ${APP2}.ods_order_detail t2
on t1.id=t2.order_id
;
"

hive -e "$sql1"