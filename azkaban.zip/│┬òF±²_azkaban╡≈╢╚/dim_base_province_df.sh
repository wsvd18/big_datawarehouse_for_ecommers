#!/bin/bash

APP=dim
APP2=tempo2

if [ -n "$2" ];then
  do_date=$2
else
  do_date=`date -d "-1 day" +%F`
fi

sql1="
set hive.exec.compress.output=false;
set mapreduce.output.fileoutputformat.compress=false;

insert overwrite table ${APP}.dim_base_province_df
select
t1.id as province_id,
t1.name as province_name,
t2.id as region_id,
t2.region_name
from ${APP2}.ods_base_province t1
join ${APP2}.ods_base_region t2
on t1.region_id=t2.id;
"

hive -e "$sql1"