#!/bin/bash
APP=dm
APP4=dws

if [ -n "$2" ];then
  do_date=$2
else
  do_date=`date -d "-1 day" +%F`
fi
hive -e "
create table if not exists {$APP}.dm_trade_province_di(
province_id string,
province_name string,
region_id string,
region_name string,
sku_num bigint,
order_count    bigint,
order_amount double,
avg_amount double,
ds_str string
);

create table if not exists {$APP}.dm_trade_sku_di(
sku_id string,
sku_name string,
sku_num bigint,
category3_id string,
category2_id string,
category1_id string,
category3_name string,
category2_name string,
category1_name string,
order_count bigint,
order_amount double,
avg_amount double,
ds_str string
);

create table if not exists {$APP}.dm_trade_age_di(
age bigint
sku_num bigint
order_count	bigint
order_amount	double
avg_amount	double
ds_str	string

);
"

sql1="
set hive.exec.compress.output=false;

INSERT OVERWRITE TABLE dm.dm_trade_province_di
SELECT
    province_id,
    province_name,
    region_id,
    region_name,
    SUM(sku_num) AS sku_num,
    COUNT(order_count) AS order_count,
    SUM(order_amount) AS order_amount,
    ROUND(AVG(order_amount), 4) AS avg_amount,
    ds_str
FROM ${APP4}.dws_trade_detail_di
GROUP BY province_id, province_name, region_id, region_name, ds_str;

INSERT OVERWRITE TABLE dm.dm_trade_age_di
SELECT
    age,
    SUM(sku_num) AS sku_num,
    COUNT(order_count) AS order_count,
    SUM(order_amount) AS order_amount,
    ROUND(AVG(order_amount), 4) AS avg_amount,
    ds_str
FROM ${APP4}.dws_trade_detail_di
GROUP BY age, ds_str;

INSERT OVERWRITE TABLE dm.dm_trade_sku_di
SELECT
    sku_id,
    sku_name,
    SUM(sku_num) AS sku_num,
    category3_id,
    category2_id,
    category1_id,
    category3_name,
    category2_name,
    category1_name,
    COUNT(order_count) AS order_count,
    SUM(order_amount) AS order_amount,
    ROUND(AVG(order_amount), 4) AS avg_amount,
    ds_str
FROM ${APP4}.dws_trade_detail_di
GROUP BY sku_id, sku_name, category3_id, category2_id, category1_id, 
         category3_name, category2_name, category1_name, ds_str;

"

hive -e "$sql1"