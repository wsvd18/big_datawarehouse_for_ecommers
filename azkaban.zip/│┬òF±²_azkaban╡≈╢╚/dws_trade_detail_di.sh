#!/bin/bash
APP=dws
APP2=dim
APP3=dwd

if [ -n "$2" ];then
  do_date=$2
else
  do_date=`date -d "-1 day" +%F`
fi

sql1="
set hive.exec.compress.output=false;

INSERT OVERWRITE TABLE ${APP}.dws_trade_detail_di
SELECT
    YEAR(CURRENT_DATE()) - YEAR(t1.birthday) AS age,
    t7.sku_id,
    SUM(t4.sku_num) OVER (PARTITION BY t4.id) AS sku_num,
    COUNT(t4.id) OVER (PARTITION BY t4.id) AS order_count,
    t4.order_amount,
    t4.order_status,
    t5.province_id,
    t5.province_name,
    t5.region_id,
    t5.region_name,
    t7.sku_name,
    t7.category1_id,
    t7.category1_name,
    t7.category2_id,
    t7.category2_name,
    t7.category3_id,
    t7.category3_name,
    t4.ds AS ds_str
FROM
    ${APP2}.dim_user_info_df t1
JOIN
    ${APP3}.dwd_fac_order_detailinfo_di t4 ON t1.id = t4.user_id
JOIN
    ${APP2}.dim_base_province_df t5 ON t4.province_id = t5.province_id
JOIN
    ${APP2}.dim_sku_info_df t7 ON t4.sku_id = t7.sku_id
WHERE
    t4.order_status NOT IN ('1003', '1005', '1006');
"

hive -e "$sql1"