#!/bin/bash

APP=dim
APP2=tempo2

if [ -n "$2" ];then
  do_date=$2
else
  do_date=`date -d "-1 day" +%F`
fi

sql1="
set hive.exec.compress.output=false;
set mapreduce.output.fileoutputformat.compress=false;

insert overwrite table ${APP}.dwd_dim_user_info_his
select 
birthday,
id,
name,
create_time,
'$do_date' start_date,
'9999-12-31' end_date
from ${APP2}.ods_user_info
where dt='$do_date'
;
"

hive -e "$sql1"