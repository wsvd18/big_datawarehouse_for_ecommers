#!/bin/bash

APP=dim
APP2=tempo2

if [ -n "$2" ];then
  do_date=$2
else
  do_date=`date -d "-1 day" +%F`
fi

sql1="
set hive.exec.compress.output=false;
set mapreduce.output.fileoutputformat.compress=false;

insert overwrite table ${APP}.dim_sku_info_df
select
t1.id AS sku_id,
t1.sku_name,
t2.id AS category3_id,
t2.name AS category3_name,
t3.id AS category2_id,
t3.name AS category2_name,
t4.id AS category1_id,
t4.name AS category1_name
from
(
select * from ${APP2}.ods_sku_info where dt='$do_date'
) t1
join
(
select * from ${APP2}.ods_base_category3 where dt='$do_date'
) t2 on t1.category3_id=t2.id
left join
(
select * from ${APP2}.ods_base_category2 where dt='$do_date'
) t3 on t2.category2_id=t3.id
left join
(
select * from ${APP2}.ods_base_category1 where dt='$do_date'
) t4 on t3.category1_id=t4.id
;
"

hive -e "$sql1"