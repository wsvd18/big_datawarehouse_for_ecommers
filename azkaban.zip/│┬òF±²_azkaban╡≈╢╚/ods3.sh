#!/bin/bash

# Configuration
IP="192.168.5.100:3306"
DB="bigdata_project_OLAP"
HDB="tempo2"
USER="root"
PWD="123456"

# Determine the date to process
if [ -n "$2" ]; then
  do_date="$2"
else
  do_date=$(date -d '-1 day' +%F)
fi

# Import data function for partitioned tables
import_data() {
  local table="$1"
  local columns="$2"
  local condition="$3"

  # Paths to delete
  local dir1="/user/hive/warehouse/$HDB.db/ods_$1/dt=$do_date"
  local dir2="/user/hive/warehouse/$HDB.db/ods_$1/_SCRATCH0.*"

  # Remove existing data if present
  hdfs dfs -test -e "$dir1" && hdfs dfs -rm -r "$dir1"
  hdfs dfs -test -e "$dir2" && hdfs dfs -rm -r "$dir2"

  # Import data
  sqoop import \
    --connect jdbc:mysql://$IP/$DB \
    --username $USER \
    --password $PWD \
    --table $1 \
    --hive-import \
    --columns "$columns" \
    --where "$condition" \
    --hive-database $HDB \
    --hive-table "ods_$1" \
    --hive-partition-key dt \
    --hive-partition-value "$do_date" \
    -m 1
}

# Import data function for non-partitioned tables
import_data_quan() {
  local table="$1"
  local columns="$2"
  local condition="$3"

  # Paths to delete
  local dir1="/user/hive/warehouse/$HDB.db/ods_$1"
  local dir2="/user/hive/warehouse/$HDB.db/ods_$1/_SCRATCH0.*"
  local dir3="/user/hadoop/$1"

  # Remove existing data if present
  hdfs dfs -test -e "$dir1" && hdfs dfs -rm -r "$dir1"
  hdfs dfs -test -e "$dir2" && hdfs dfs -rm -r "$dir2"
  hdfs dfs -test -e "$dir3" && hdfs dfs -rm -r "$dir3"

  # Import data
  sqoop import \
    --connect jdbc:mysql://$IP/$DB \
    --username $USER \
    --password $PWD \
    --table $1 \
    --hive-import \
    --columns "$columns" \
    --where "$condition" \
    --hive-database $HDB \
    --hive-table "ods_$1" \
    -m 1
}

# Define import functions for each table
import_user_info() {
  import_data "user_info" "id,name,phone_num,email,user_level,birthday,gender,create_time,operate_time" \
    "(DATE_FORMAT(create_time, '%Y-%m-%d')='$do_date' OR DATE_FORMAT(operate_time, '%Y-%m-%d')='$do_date')"
}

import_base_category1() {
  import_data_quan "base_category1" "id,name" "1=1"
}

import_base_category2() {
  import_data_quan "base_category2" "id,name,category1_id" "1=1"
}

import_base_category3() {
  import_data_quan "base_category3" "id,name,category2_id" "1=1"
}

import_spu_info() {
  import_data_quan "spu_info" "id,spu_name,category3_id,tm_id" "1=1"
}

import_sku_info() {
  import_data_quan "sku_info" "id,sku_name,sku_desc,category3_id,create_time" "1=1"
}

import_order_info() {
  import_data "order_info" "id,original_total_amount,user_id,order_status,create_time,operate_time,province_id" \
    "DATE_FORMAT(create_time, '%Y-%m-%d')='$do_date' OR DATE_FORMAT(operate_time, '%Y-%m-%d')='$do_date'"
}

import_order_detail() {
  import_data "order_detail" "id,order_id,sku_id,sku_name,order_price,sku_num,create_time" \
    "DATE_FORMAT(create_time, '%Y-%m-%d')='$do_date'"
}

import_base_province() {
  import_data_quan "base_province" "id,name,region_id" "1=1"
}

import_base_region() {
  import_data_quan "base_region" "id,region_name" "1=1"
}

# Main execution based on the input argument
case $1 in
  "user_info")
    import_user_info
    ;;
  "base_category1")
    import_base_category1
    ;;
  "base_category2")
    import_base_category2
    ;;
  "base_category3")
    import_base_category3
    ;;
  "spu_info")
    import_spu_info
    ;;
  "sku_info")
    import_sku_info
    ;;
  "order_info")
    import_order_info
    ;;
  "order_detail")
    import_order_detail
    ;;
  "base_province")
    import_base_province
    ;;
  "base_region")
    import_base_region
    ;;
  "all")
    import_user_info
    import_order_info
    import_order_detail
    import_sku_info
    import_base_category1
    import_base_category2
    import_base_category3
    import_base_province
    import_base_region
    ;;
  *)
    echo "Usage: $0 {user_info|base_category1|base_category2|base_category3|spu_info|sku_info|order_info|order_detail|base_province|base_region|all}"
    exit 1
    ;;
esac
